<header class="text-center">
    <img src="<?php echo e(asset('assets/images/logo-mono.png')); ?>" alt="Univ. Hasanuddin" class="float-left"
        style="height: 100px; position: relative; top: 20px">
    <h4 class="mb-0">
        KEMENTERIAN PENDIDIKAN, KEBUDAYAAN, RISET DAN TEKNOLOGI <br>
        UNIVERSITAS HASANUDDIN <br>
        <b>FAKULTAS KEDOKTERAN</b>
    </h4>
    <p style="margin-bottom: -8px">
        Jl. Perintis Kemerdekaan Kampus Tamalanrea Km. 10 Makassar 90245
    </p>
    <p>
        Telp. ( 0411 ) 586010, 585836, 586200 Psw. 2767 Fax. (0411) 586297 email:fkunhas@med.unhas.ac.id
    </p>
    <hr>
</header>
<?php /**PATH C:\laragon\www\simfk\resources\views/surat/header.blade.php ENDPATH**/ ?>